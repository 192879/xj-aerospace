# xj-aerospace 校园招聘官网

打开 `index.html` 即可预览。可直接上传到 Vercel / Netlify / Cloudflare Pages。

## 替换邮箱
在 `index.html` 搜索 `hr@xj-aerospace.com`，替换为你的企业邮箱。

## 替换二维码
当前二维码区域是占位视觉。你之后提供网站链接后，可以生成真实二维码图片并替换 `.qr` 区域。
