window.addEventListener('load',()=>{setTimeout(()=>document.getElementById('loader').classList.add('hide'),650)});
const io=new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('show')})},{threshold:.15});
document.querySelectorAll('.reveal').forEach(el=>io.observe(el));
// 视差效果：鼠标移动时让主视觉飞行器轻微跟随
const hero=document.querySelector('.hero');
hero?.addEventListener('mousemove',e=>{
  const x=(e.clientX/window.innerWidth-.5)*18;
  const y=(e.clientY/window.innerHeight-.5)*18;
  document.querySelector('.fighter').style.transform=`translate(${x}px,${y}px)`;
  document.querySelector('.rocket').style.transform=`translate(${-x/2}px,${-y/2}px)`;
});
